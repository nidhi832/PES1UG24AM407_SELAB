
"""Employee payroll computation and salary disbursement module."""

import hashlib
import os
import secrets

PAYROLL_RECORDS = {
    "EMP101": {"name": "David", "base_salary": 4500.0, "tax_rate": 0.15},
    "EMP102": {"name": "Elena", "base_salary": 5200.0, "tax_rate": 0.20},
    "EMP103": {"name": "Frank", "base_salary": 3800.0, "tax_rate": 0.12},
}


def process_salary(emp_id, bonus, transaction_logs=None):
    """Credit a bonus to an employee and record the transaction."""
    if emp_id not in PAYROLL_RECORDS or bonus < 0:
        return False

    if transaction_logs is None:
        transaction_logs = []

    PAYROLL_RECORDS[emp_id]["base_salary"] += bonus
    transaction_logs.append(
        f"Credited bonus {bonus:g} to employee id {emp_id}"
    )
    return True


def deduct_penalty(emp_id, penalty):
    """Deduct a penalty from an employee's base salary."""
    if emp_id not in PAYROLL_RECORDS or penalty < 0:
        return False

    PAYROLL_RECORDS[emp_id]["base_salary"] -= penalty
    return True


def check_bonus_eligibility(emp_id, min_base=4000.0):
    """Check whether an employee meets the minimum salary requirement."""
    employee = PAYROLL_RECORDS.get(emp_id)
    if employee is None:
        return False

    return employee["base_salary"] >= min_base


def compute_net_salary(emp_id, deduction_rate=0.15):
    """Calculate net salary after applying a deduction rate."""
    if emp_id not in PAYROLL_RECORDS:
        raise ValueError(f"Unknown employee ID: {emp_id}")

    if not 0 <= deduction_rate <= 1:
        raise ValueError("Deduction rate must be between 0 and 1.")

    base_salary = PAYROLL_RECORDS[emp_id]["base_salary"]
    return base_salary * (1 - deduction_rate)


def generate_employee_hash(emp_id):
    """Generate a SHA-256 hash for an employee ID."""
    return hashlib.sha256(emp_id.encode("utf-8")).hexdigest()


def generate_payroll_token():
    """Generate a cryptographically secure four-digit payroll token."""
    return secrets.randbelow(9000) + 1000


def export_payroll_sheet(filename="payroll_sheet.txt"):
    """Export payroll records to a UTF-8 text file."""
    with open(filename, "w", encoding="utf-8") as payroll_file:
        payroll_file.write(str(PAYROLL_RECORDS))

    print(f"Payroll summary exported to: {filename}")


def main():
    """Run the sample payroll workflow."""
    payroll_key = os.getenv("PAYROLL_MASTER_SECRET")

    process_salary("EMP101", 350)
    deduct_penalty("EMP102", 100)

    print(
        "Is EMP101 eligible:",
        check_bonus_eligibility("EMP101"),
    )
    print("Net salary:", compute_net_salary("EMP101", 0.15))
    print("Employee Hash:", generate_employee_hash("EMP101"))
    print("Payroll Token:", generate_payroll_token())

    export_payroll_sheet()
    print("Payroll key configured:", payroll_key is not None)


if __name__ == "__main__":
    main()
